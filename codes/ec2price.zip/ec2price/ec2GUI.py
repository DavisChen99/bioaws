#!/usr/bin/python
# -*- coding:utf-8 -*-
import os
import sys
from tkinter import *
import tkinter.filedialog
import tkinter.font as tf

# NEED CHANGE to the dir you want to put the crawled data

# judge the system type
if 'win' in sys.platform:
    mysystem = 'Windows'
else:
    mysystem = 'Non-Windows'

##  Functions

def insoption(inscom): # li/win/su/rh/wsqs/wsqw/wsqe
	if inscom == '按需实例':
		insoption = 'od'
	elif inscom =='专用按需实例':
		insoption = 'do'
	elif inscom =='预留实例':
		insoption = 'ri'
	elif inscom =='专用预留实例':
		insoption = 'dri'
	elif inscom =='可转换实例':
		insoption = 'cri'
	elif inscom =='可转换专用预留实例':
		insoption = 'cdri'
	return insoption

def osoption(oscombo): # li/win/su/rh/wsqs/wsqw/wsqe
	if oscombo == 'Linux':
		toption = 'li'
	elif oscombo =='Windows':
		toption = 'win'
	elif oscombo =='SUSE':
		toption = 'su'
	elif oscombo =='RHEL':
		toption = 'rh'
	elif oscombo =='SQL Standard Windows':
		toption = 'wsqs'
	elif oscombo =='SQL Web Windows':
		toption = 'wsqw'
	elif oscombo =='SQL Server Ent Windows':
		toption = 'wsqe'
	return toption

########################################################## GUI SETTING ##########################################################
ec2 = Tk()
ec2.resizable(width=False, height=False)
# set center pos
sw = ec2.winfo_screenwidth()
sh = ec2.winfo_screenheight()
ww = 800
wh = 400
x = (sw-ww) / 2
y = (sh-wh) / 2
ec2.geometry("%dx%d+%d+%d" %(ww,wh,x,y))

# # file select
ec2.title('AWS China EC2 Price Query')

# your OS
mode_label = Label(ec2, text = 'OS: '+ mysystem).grid(row=0, column=0,sticky=E)


# mode
mode_label = Label(ec2, text = 'Mode:').grid(row=1, column=0,sticky=E)
mode_var = StringVar()
mode_var.set('off')
Radiobutton(ec2,text='online', variable = mode_var,value='on').grid(row=1,column=1, sticky=W, padx=5, pady=5)
Radiobutton(ec2,text='offline', variable = mode_var,value='off').grid(row=1,column=1, padx=5, pady=5)
Radiobutton(ec2,text='update', variable = mode_var,value='update').grid(row=1,column=1, sticky=E, padx=5, pady=5)


# Region
region_label = Label(ec2, text = 'Region:').grid(row=2, column=0,sticky=E)
region_var = StringVar()
region_var.set('zhy')
Radiobutton(ec2,text='北京', variable = region_var,value='bjs').grid(row=2,column=1, sticky=W, padx=5, pady=5)
Radiobutton(ec2,text='宁夏', variable = region_var,value='zhy').grid(row=2,column=1, padx=5, pady=5)

# Instane
from tkinter import ttk
ins_label = Label(ec2, text = 'PurchaseType:').grid(row=3, column=0,sticky=E)
ins_var = StringVar()
ins_combo = ttk.Combobox(ec2,textvariable=ins_var,width=25)
ins_combo.grid(row=3, column=1, sticky=W, padx=5, pady=5)
ins_combo["value"] = ('按需实例', '专用按需实例', '预留实例','专用预留实例','可转换实例','可转换专用预留实例')  
ins_combo.current(2)

# OS
from tkinter import ttk
os_label = Label(ec2, text = 'Operation system:').grid(row=4, column=0,sticky=E)
os_var = StringVar()
os_combo = ttk.Combobox(ec2,textvariable=os_var,width=25)
os_combo.grid(row=4, column=1, sticky=W, padx=5, pady=5)
os_combo["value"] = ('Linux', 'Windows', 'SUSE','RHEL','SQL Standard Windows','SQL Web Windows','SQL Server Ent Windows')  
os_combo.current(0)

# Instance Type
# inst_label = Label(ec2, text = '实例类型:').grid(row=5, column=0,sticky=W)
# inst = Entry(ec2,width=75)
# inst.grid(row=5,column=1, sticky=W,columnspan=3, padx=5, pady=5)
# inst_var = inst.get()

input_label = Label(ec2, text = 'InstanceType:').grid(row=5, column=0,sticky=E)
input_var1 = StringVar()
input_combo1 = ttk.Combobox(ec2,textvariable=input_var1,width=8)
input_combo1.grid(row=5, column=1, sticky=W, padx=5, pady=5)
input_combo1["value"] = ('t3', 't3a', 't2',
						'm6g','m5','m5a','m5d','m4','m3',
						'c6g','c5','c5d','c4','c3',
						'p2','p3','g4dn','g3','g3s','g2',
						'x1','r6g','r5','r5a','r5d','r4','r3',
						'z1d','i3','i2','d2') 
input_combo1.current(4)

# input_label = Label(ec2, text = '+').grid(row=5, column=1,sticky=E) 
input_var2 = StringVar()
input_combo2 = ttk.Combobox(ec2,textvariable=input_var2,width=10)
input_combo2.grid(row=5, column=1, padx=5, pady=5)
input_combo2["value"] = ('nano','micro','small','medium','large','xlarge','2xlarge',
						'4xlarge','8xlarge','9xlarge','10xlarge','12xlarge','16xlarge','24xlarge','32xlarge','metal',  )
input_combo2.current(4)


## Run
# opt_mode = mode_var.get()
# opt_region = region_var.get()
# opt_instancetype = insoption(ins_combo.get())
# opt_os = osoption(os_combo.get())
# opt_insts = input_combo1.get() + '.' + input_combo2.get()

# Show result 
result_label = Label(ec2, text = 'Query Result:').grid(row=6, column=0,sticky=E)
text = Text(ec2,width=97,height=10,font=('Arial', 10), fg = 'blue')
text.grid(row=6,column=1, sticky=W,columnspan=3, padx=5, pady=5)
# text.configure(state='readonly')



def show():
    try:
    	f = sys.stdout
    	f = os.popen('ec2main.py -r %s -m %s -t %s -s %s %s' % (region_var.get(),mode_var.get(),insoption(ins_combo.get()),osoption(os_combo.get()),input_combo1.get() + '.' + input_combo2.get()))
    	text.delete(1.0, END)
    	for line in iter(f.readline, ''):
    		text.insert(END,line)
	    	text.see(END)
	    	text.update()
    except:
        win32api.MessageBox(0, "文件读写错误！",
                    "警告！",win32con.MB_OK)

def delete():
	text.delete(1.0, END)

Label(ec2, text = 'powered by D.C',font=('Arial', 8)).grid(row=7, column=0,sticky=W) 
Button(ec2, text='Clear', width=10,command = delete).grid(row=5,column=2, columnspan=2, padx=5, pady=5,sticky=E)  
Button(ec2, text='Submit', width=10,command = show).grid(row=5,column=1, padx=5, pady=5,sticky=E)  
ec2.mainloop()

